<?php include __DIR__ . '/../include/header.php'; ?>
<?php include __DIR__ . '/../include/menu.php'; ?>

<h2>Remover sessão</h2>

<?php include __DIR__ . '/../include/mensagem.php'; ?>

<?php if ($existe): ?>
    <p>Ao remover, os dados do livro serão apagados e a sessão destruída (use quando terminar de ler).</p>
<?php endif; ?>

<form action="index.php?acao=excluir" method="post">
    <button type="submit" class="btn btn-danger">Remover</button>
</form>

<?php include __DIR__ . '/../include/footer.php'; ?>
