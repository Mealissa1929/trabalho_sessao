<?php include __DIR__ . '/../include/header.php'; ?>
<?php include __DIR__ . '/../include/menu.php'; ?>

<h2>Livro atual</h2>

<?php if ($livro === null): ?>
    <div class="alert alert-warning" role="alert">Sessão não existe!</div>
<?php else: ?>
    <ul class="list-group">
        <li class="list-group-item"><strong>Nome:</strong> <?= htmlspecialchars($livro->getNome()) ?></li>
        <li class="list-group-item"><strong>Autor:</strong> <?= htmlspecialchars($livro->getAutor()) ?></li>
        <li class="list-group-item"><strong>Total de páginas:</strong> <?= $livro->getTotalPaginas() ?></li>
        <li class="list-group-item"><strong>Página atual:</strong> <?= $livro->getPaginaAtual() ?></li>
    </ul>
<?php endif; ?>

<?php include __DIR__ . '/../include/footer.php'; ?>
