<?php include __DIR__ . '/../include/header.php'; ?>
<?php include __DIR__ . '/../include/menu.php'; ?>

<h2>Criar livro</h2>

<?php include __DIR__ . '/../include/mensagem.php'; ?>

<form action="index.php?acao=criar" method="post">
    <div class="mb-3">
        <label for="nome" class="form-label">Nome do livro</label>
        <input type="text" class="form-control" id="nome" name="nome">
    </div>
    <div class="mb-3">
        <label for="autor" class="form-label">Autor</label>
        <input type="text" class="form-control" id="autor" name="autor">
    </div>
    <div class="mb-3">
        <label for="totalPaginas" class="form-label">Total de páginas</label>
        <input type="number" class="form-control" id="totalPaginas" name="totalPaginas" min="1">
    </div>
    <button type="submit" class="btn btn-primary">Criar</button>
</form>

<?php include __DIR__ . '/../include/footer.php'; ?>
