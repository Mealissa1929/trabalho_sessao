<?php include __DIR__ . '/../include/header.php'; ?>
<?php include __DIR__ . '/../include/menu.php'; ?>

<h2>Alterar página atual</h2>

<?php include __DIR__ . '/../include/mensagem.php'; ?>

<?php if ($livro !== null): ?>
    <p>
        <strong><?= htmlspecialchars($livro->getNome()) ?></strong>
        (página atual: <?= $livro->getPaginaAtual() ?> de <?= $livro->getTotalPaginas() ?>)
    </p>
<?php endif; ?>

<form action="index.php?acao=alterar" method="post">
    <div class="mb-3">
        <label for="paginaAtual" class="form-label">Nova página atual</label>
        <input type="number" class="form-control" id="paginaAtual" name="paginaAtual" min="0">
    </div>
    <button type="submit" class="btn btn-primary">Alterar</button>
</form>

<?php include __DIR__ . '/../include/footer.php'; ?>
