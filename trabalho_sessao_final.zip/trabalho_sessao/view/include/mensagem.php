<?php if (!empty($mensagem)): ?>
    <div class="alert alert-<?= $tipo ?>" role="alert">
        <?= htmlspecialchars($mensagem) ?>
    </div>
<?php endif; ?>
