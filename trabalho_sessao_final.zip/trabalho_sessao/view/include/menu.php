<nav class="nav nav-pills my-3">
    <a class="nav-link" href="index.php?acao=exibir">Exibir</a>
    <a class="nav-link" href="index.php?acao=criar">Criar</a>
    <a class="nav-link" href="index.php?acao=alterar">Alterar</a>
    <a class="nav-link" href="index.php?acao=excluir">Remover</a>
</nav>
