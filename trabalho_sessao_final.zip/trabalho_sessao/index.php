<?php

require_once __DIR__ . '/model/Livro.php';
require_once __DIR__ . '/sessao/LivroSessao.php';
require_once __DIR__ . '/controller/LivroController.php';

session_start();

$acao = $_GET['acao'] ?? 'exibir';

$controller = new LivroController();

switch ($acao) {
    case 'criar':
        $controller->criar();
        break;
    case 'alterar':
        $controller->alterar();
        break;
    case 'excluir':
        $controller->excluir();
        break;
    default:
        $controller->exibir();
        break;
}
