<?php

class LivroController
{
    public function criar(): void
    {
        $mensagem = null;
        $tipo = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nome = trim($_POST['nome'] ?? '');
            $autor = trim($_POST['autor'] ?? '');
            $totalPaginas = (int) ($_POST['totalPaginas'] ?? 0);

            if ($nome === '' || $autor === '' || $totalPaginas <= 0) {
                $mensagem = 'Preencha todos os campos. O total de páginas deve ser maior que zero.';
                $tipo = 'danger';
            } else {
                $livro = new Livro($nome, $autor, $totalPaginas);

                if (LivroSessao::criar($livro)) {
                    $mensagem = 'Livro guardado na sessão com sucesso!';
                    $tipo = 'success';
                } else {
                    $mensagem = 'Já existe um livro na sessão! Remova-o antes de criar outro.';
                    $tipo = 'danger';
                }
            }
        }

        include __DIR__ . '/../view/livros/criar.php';
    }

    public function alterar(): void
    {
        $mensagem = null;
        $tipo = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $livro = LivroSessao::buscar();

            if ($livro === null) {
                $mensagem = 'Sessão não existe! Crie um livro primeiro.';
                $tipo = 'danger';
            } else {
                $pagina = (int) ($_POST['paginaAtual'] ?? -1);

                if ($pagina < 0 || $pagina > $livro->getTotalPaginas()) {
                    $mensagem = 'A página atual deve estar entre 0 e ' . $livro->getTotalPaginas() . '.';
                    $tipo = 'danger';
                } else {
                    LivroSessao::alterarPagina($pagina);
                    $mensagem = 'Página atual alterada com sucesso!';
                    $tipo = 'success';
                }
            }
        }

        $livro = LivroSessao::buscar();

        include __DIR__ . '/../view/livros/alterar.php';
    }

    public function excluir(): void
    {
        $mensagem = null;
        $tipo = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!LivroSessao::existe()) {
                $mensagem = 'Sessão não existe! Não há nada para remover.';
                $tipo = 'danger';
            } else {
                LivroSessao::remover();
                $mensagem = 'Sessão removida! Agora você pode criar um novo livro.';
                $tipo = 'success';
            }
        }

        $existe = LivroSessao::existe();

        include __DIR__ . '/../view/livros/excluir.php';
    }

    public function exibir(): void
    {
        $livro = LivroSessao::buscar();

        include __DIR__ . '/../view/livros/exibir.php';
    }
}
