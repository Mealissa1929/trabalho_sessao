<?php if (!empty($mensagem)): ?>
    <div class="alert alert-<?= htmlspecialchars($tipo) ?>" role="alert">
        <?= htmlspecialchars($mensagem) ?>
    </div>
<?php endif; ?>
