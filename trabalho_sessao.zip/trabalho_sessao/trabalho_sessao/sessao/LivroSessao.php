<?php

class LivroSessao
{
    private const CHAVE = 'livro';

    public static function existe(): bool
    {
        return isset($_SESSION[self::CHAVE]);
    }

    public static function criar(Livro $livro): bool
    {
        if (self::existe()) {
            return false;
        }
        $_SESSION[self::CHAVE] = $livro;
        return true;
    }

    public static function buscar(): ?Livro
    {
        return self::existe() ? $_SESSION[self::CHAVE] : null;
    }

    public static function alterarPagina(int $pagina): bool
    {
        if (!self::existe()) {
            return false;
        }
        $livro = $_SESSION[self::CHAVE];
        $livro->setPaginaAtual($pagina);
        $_SESSION[self::CHAVE] = $livro;
        return true;
    }

    public static function remover(): void
    {
        $_SESSION = [];

        session_destroy();
    }
}
