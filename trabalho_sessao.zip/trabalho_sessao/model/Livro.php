<?php

class Livro{
    private ?string $nome;
    private ?string $autor;
    private ?int $totalPaginas;
    private ?int $paginaAtual;

    public function __construct($n, $a, $tp){
        $this->paginaAtual = 0;
        $this->nome = $n;
        $this->autor = $a;
        $this->totalPaginas = $tp;
    }

    public function getNome(): ?string
    {
        return $this->nome;
    }

    public function setNome(?string $nome): self
    {
        $this->nome = $nome;

        return $this;
    }

    public function getAutor(): ?string
    {
        return $this->autor;
    }

    public function setAutor(?string $autor): self
    {
        $this->autor = $autor;

        return $this;
    }

    public function getTotalPaginas(): ?int
    {
        return $this->totalPaginas;
    }

    public function setTotalPaginas(?int $totalPaginas): self
    {
        $this->totalPaginas = $totalPaginas;

        return $this;
    }

    public function getPaginaAtual(): ?int
    {
        return $this->paginaAtual;
    }

    public function setPaginaAtual(?int $paginaAtual): self
    {
        $this->paginaAtual = $paginaAtual;

        return $this;
    }
}